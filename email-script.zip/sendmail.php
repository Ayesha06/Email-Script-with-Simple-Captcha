<?php
session_start();
$email_check = '';
$return_json = '';  
  include("captcha/securimage.php");
  $img = new Securimage();
  $valid = $img->check($_REQUEST['code']);
if($valid == true) {
  
/*echo '<pre>';
print_r($_POST);
echo '</pre>';
exit();*/
define("SUBJECT","Project Title");

  if(empty($_POST["fullname"]) || empty($_POST["email"]) || empty($_POST["phone"]) || empty($_POST["message"])){
	$email_check = "Please fill all required fields.";	
	$return_json = '{"email_check":"' . $email_check . '"}';
	echo $return_json;	
  }
  
  $subject = SUBJECT.', Contact Us';
  $email_subject = 'Contact Us';
  
  $to = 'toemail@acbc.com';
 
  $strFrom = $_POST["email"];
  //$subject = SUBJECT.', Contact Us Request';

// message
$message = '<table width="610" border="0" cellspacing="0" cellpadding="0"><tr><td style="padding:23px 23px 16px 23px; background:#f5f5f6; font-family: tahoma; width:610px;"><table width="600" border="0" cellspacing="0" cellpadding="0"><tr><td style="background:#FFFFFF; padding:10px 0px 10px 0px; border:1px solid #dcdcdc;"><table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td>&nbsp;</td>
              </tr>
            <tr>
              <td><img src="images/logo.png" width="200" style="float:left; margin-left:20px;" /><h4 style="float:left;display:block;margin:20px 0px 0px 50px;padding-left:20px;color:#000000">&nbsp;&nbsp;&nbsp;'.$email_subject.'</h4></td>
              </tr>
            <tr>
              <td align="right">&nbsp;</td>
            </tr>
          </table></td></tr><tr><td style="height:1px; background-color:#eeeeee"></td></tr><tr><td style="font-family: tahoma; size:12px; background-color:#FFFFFF;  border:1px solid #dcdcdc; padding:10"><div style="width:600px; font-size: 12px; background:#ffffff;"><br />
<b style="padding-left:20px;">Hello Administrator,</b>
<p style="padding-left:20px;">A new '.$email_subject.' request is posted. Here are the details of the request:<br /><br /></p>

<table width="582" border="0" cellpadding="0" cellspacing="2">
                  
				  <tr>
                    <td width="183" height="21" align="right"><span style="font-size:11px; font-family:Arial, Helvetica, sans-serif;"><strong>Full Name:</strong>&nbsp; </span></td>
                    <td width="393" align="left"><span style="font-size:11px; font-family:Arial, Helvetica, sans-serif;">'.$_POST["fullname"].'</span></td>
                </tr>
                <tr>
                    <td height="21" align="right"><span style="font-size:11px; font-family:Arial, Helvetica, sans-serif;"><strong>Email:&nbsp;</strong></span></td>
                    <td align="left"><span style="font-size:11px; font-family:Arial, Helvetica, sans-serif;"><a href="mailto:'.$_POST["email"].'">'.$_POST["email"].'</a></span></td>
                </tr>
				<tr>
                    <td width="183" height="21" align="right"><span style="font-size:11px; font-family:Arial, Helvetica, sans-serif;"><strong>Phone:</strong>&nbsp; </span></td>
                    <td width="393" align="left"><span style="font-size:11px; font-family:Arial, Helvetica, sans-serif;">'.$_POST["phone"].'</span></td>
                </tr>
				<tr>
                    <td width="183" height="21" align="right"><span style="font-size:11px; font-family:Arial, Helvetica, sans-serif;"><strong>Subject:</strong>&nbsp; </span></td>
                    <td width="393" align="left"><span style="font-size:11px; font-family:Arial, Helvetica, sans-serif;">'.$_POST["subject"].'</span></td>
                </tr>
								  				  
                  <tr>
                    <td height="21" align="right" valign="top"><span style="font-size:11px; font-family:Arial, Helvetica, sans-serif;"><strong>Message:&nbsp;</strong></span></td>
                    <td align="left" valign="top"><table width="393" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><span style="font-size:11px; font-family:Arial, Helvetica, sans-serif;">'.$_POST["message"].'</span></td>
  </tr>
</table></td>
                  </tr>
              </table>

<br /><br />
</div></td>
</tr><tr><td></td></tr></table><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td style="font-size:10px; color:#a0a0a0; padding:5px 15px 5px 0px; font-family: tahoma;">This message was intended for <a href="mailto:'.$to.'">'.$to.'</a>.  You received this email because a new '.$email_subject.' request has been posted on '.SUBJECT.'.</strong></td></tr></table></td></tr></table>';
			
/*echo $message;
exit;*/

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
$headers .= 'From: <'.$strFrom.'>' . "\r\n";
//$headers .= 'Cc: <zehrawkhan@gmail.com>' . "\r\n";
$headers .= 'Reply-To: <'.$strFrom.'>' . "\r\n";

$mail = mail($to,$subject,$message,$headers);

		if($mail){
			$email_check = "OK";
		} else{
			$email_check = "There was an error while submitting your request, please try again.";	
		}		
}else{
	$email_check = "Sorry, the code you entered was invalid. Please try again.";
}

$return_json = '{"email_check":"' . $email_check . '"}';
	
echo $return_json;	
?>